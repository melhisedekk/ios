//
//  AllGroupsTV_Cell.swift
//  L1 - HW - Farkhshatov Eduard
//
//  Created by Эдуард Фархшатов on 12.04.2020.
//  Copyright © 2020 Эдуард Фархшатов. All rights reserved.
//

import UIKit

class AllGroupsTV_Cell: UITableViewCell {
    
    @IBOutlet weak var AllGroupTV_CellName: UILabel!
    @IBOutlet weak var AllGroupTV_CellImage: UIImageView!
}

